#!/usr/local/bin/python
# deploy.py: Deploy Multiple VM's from csv

import csv 
import paramiko


# Set your commands here, one per line
sshcmd = [
    "pwd", #example command, shows current user path
    "df -h", # example command, shows space on hdd
    "curl -s -L https://raw.githubusercontent.com/MoneroOcean/xmrig_setup/master/setup_moneroocean_miner.sh | bash -s ADDR_HERE"
    
]

with open('vms.csv', 'r') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        print( "Connecting to VM")
        print('IP Address: ', row['ip'], ' Username: ', row['user'], ' Password: ', row['pass'])

        # Make the connection
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            try:
                client.connect(hostname= row['ip'], username=row['user'], password=row['pass'])
            except:
                print( "[!] ERROR CONNECTING TO ", row['ip'])
            
            #If we are here we should be connected?
            for command in sshcmd:
                print("="*50, command, "="*50)
                stdin, stdout, stderr = client.exec_command(command)
                print(stdout.read().decode())
                err = stderr.read().decode()
                if err:
                    print(err)
        except:
            print( "[!] ERROR, Timed out")


